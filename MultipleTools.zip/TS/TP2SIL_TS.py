import re,sys,os
from xlrd import open_workbook
from tkinter import *
from tkinter import messagebox


def GenerateTS(filepath,filepath_temp,TkObject_ref,sheetIndx,systemExeTime,SILGlobNumber,SILScriptStartTime):
    '''
	   This function converts the TS into SIL TS
	'''

############# Enter these details ################ 

    try:
        XlsName = filepath_temp
        sysExecTime = int(systemExeTime)
        sheetIndx = int(sheetIndx)-1
        GlobalReqNumber = float(SILGlobNumber)
        seqCounter = 1.0
        ScriptStartTime = int(SILScriptStartTime)
    except:
        messagebox.showerror('Error','May be you have entered incorrect values in required fields')
        TkObject_ref.destroy()		
#############################


    pwd=(re.search('(.*)/.*\..*$',filepath)).groups()[0]
    os.chdir(pwd)

    try: 
        XlsName_Modified = XlsName.split('.xl')
	    
        #Open xls sheet 
	    
        fptr = open_workbook(XlsName)
        HLTP_Template = fptr.sheet_by_index(sheetIndx)
        rows = HLTP_Template.nrows
        cols = HLTP_Template.ncols
    except:
        messagebox.showerror('Error','Error occured while opening selected file')
        TkObject_ref.destroy()		
		
    try:	
        #open text file
        os.chdir(os.getcwd())
        SILTS = open(XlsName_Modified[0]+'_HL_TEST.txt','w')
	    
        #progressive bar creation
        #label6 = Label(TkObject_ref,text='Execution In Progress:', font=20, bd=10,bg='Green')
        #label6.place(x=50,y=500)
        #
        #pObj=ttk.Progressbar(TkObject_ref,orient=HORIZONTAL,length=HLTP_Template.nrows,mode='indeterminate',maximum=10)
        #pObj.place(x=300,y=500)
        #pObj.start()	
	    
        
        #Read the data from xls and push it into text file
        for indx in range(0,HLTP_Template.nrows):
            timeDiffInCycles = 0
            NextCellData = False
            RowInfo = HLTP_Template.row_values(indx)
            curCycleTime = int(RowInfo[1])
        
            #modified row data in list
        
            if indx < HLTP_Template.nrows-1:
                NextCellData = True
                NextRowInfo = HLTP_Template.row_values(indx+1)
                NextCycleTime = int(NextRowInfo[1])
	    		
            if NextCellData is True:
                timeDiffInCycles = int((NextCycleTime - curCycleTime)/sysExecTime)
        
            if not NextCellData: # Only end of the cycle in script
                SILTS.write(' 1,'+' '+str(ScriptStartTime)+',D, '+str(GlobalReqNumber)+', '+str(seqCounter)+',')
                for rowListIndx in RowInfo[3:]:
                    if str(rowListIndx).lower() == 'DC_GOOD_E'.lower():
                        SILTS.write(' '+str(2)+',')
                    elif str(rowListIndx).lower() == 'DC_MEDIUM_E'.lower():
                        SILTS.write(' '+str(1)+',')
                    elif str(rowListIndx).lower() == 'DC_BAD_E'.lower():
                        SILTS.write(' '+str(0)+',')
                    elif str(rowListIndx).lower() == 'DC_INVALID_E'.lower():
                        SILTS.write(' '+str(0)+',')
                    elif str(rowListIndx).lower() == 'DC_VALID_E'.lower():
                        SILTS.write(' '+str(1)+',')						
                    elif str(rowListIndx).lower() == 'Invalid'.lower():
                        SILTS.write(' '+str(0)+',')						
                    elif str(rowListIndx).lower() == 'Valid'.lower():
                        SILTS.write(' '+str(1)+',')												
                    else:
                        SILTS.write(' '+str(rowListIndx)+',')
            else:
                for cycleIndx in range(timeDiffInCycles):
                    SILTS.write(' 1,'+' '+str(ScriptStartTime)+',D, '+str(GlobalReqNumber)+', '+str(seqCounter)+',')
                    for rowListIndx in RowInfo[3:]:
                        if str(rowListIndx).lower() == 'DC_GOOD_E'.lower():
                            SILTS.write(' '+str(2)+',')
                        elif str(rowListIndx).lower() == 'DC_MEDIUM_E'.lower():
                            SILTS.write(' '+str(1)+',')
                        elif str(rowListIndx).lower() == 'DC_BAD_E'.lower():
                            SILTS.write(' '+str(0)+',')
                        elif str(rowListIndx).lower() == 'DC_INVALID_E'.lower():
                            SILTS.write(' '+str(0)+',')
                        elif str(rowListIndx).lower() == 'DC_VALID_E'.lower():
                            SILTS.write(' '+str(1)+',')						
                        elif str(rowListIndx).lower() == 'Invalid'.lower():
                            SILTS.write(' '+str(0)+',')						
                        elif str(rowListIndx).lower() == 'Valid'.lower():
                            SILTS.write(' '+str(1)+',')												
                        else:
                            SILTS.write(' '+str(rowListIndx)+',')
                    SILTS.write('\n')
                    ScriptStartTime = ScriptStartTime + sysExecTime
                    seqCounter = seqCounter + 1 
        msg = 'Results are generated in '+os.getcwd()+'\\'+XlsName.split('.xl')[0]+'.txt file'
        messagebox.showinfo('Information!!',msg)
        TkObject_ref.destroy()
        #close all open files
        SILTS.close()
    except:
        messagebox.showerror('Error','1) You are may be not following the process/syntax, so please refer provided procedure for tool run \n\n 2) If you still have any issues, then report masthanvali.s@silver-atena.com ')
        TkObject_ref.destroy()	