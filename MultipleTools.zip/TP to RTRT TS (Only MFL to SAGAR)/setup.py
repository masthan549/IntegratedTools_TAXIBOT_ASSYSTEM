from cx_Freeze import setup, Executable

EXE = 'TP2RTRTTS_GUI'
filename = EXE+'.py'

setup(
    name = EXE ,
    version = "0.1" ,
    description = "" ,
    executables = [Executable(filename)] ,
    )							 