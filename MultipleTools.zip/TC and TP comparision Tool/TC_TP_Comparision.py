import sys,os,re
from xlrd import open_workbook
from xlsxwriter import *
from collections import OrderedDict


def readTestValues(selectedSheetPtr, testCaseSheet):
    singleDictVal = {}  # {'TXB-HLC-TC_5220': {'swpd_enum_Skf1Valid': 'Valid'}, continues}
    multiDictVal = {}  # {'TXB-HLC-TC_5222': [{'t': {'swpd_enum_Skf1Valid': 'Valid'}}, {'t+1': {'swpd_enum_Skf1Valid': 'Valid'}}, {'t+9': {'swpd_enum_Skf1Valid': 'Valid'}}, {'t+10': {'swpd_enum_Skf1Valid': 'Invalid'}}, {'t+11': {'swpd_enum_Skf1Valid': 'Invalid'}}, {'t+19': {'swpd_enum_Skf1Valid': 'Invalid'}}, {'t+20': {'swpd_enum_Skf1Valid': 'Valid'}}], continues}

    stepCounter = 1
    tempMultiList = []
    multiStep = False
    testcaseNumber = ''

    if testCaseSheet is True:
        #Fill with Test case index values
        TCObjectNumberIndex = 1
        rowStartTime = 10
    
    else:
        #TP values
        TCObjectNumberIndex = 5	
        rowStartTime = 8
	
    for colIndx in range(2, selectedSheetPtr.ncols):
        if selectedSheetPtr.ncols != colIndx+1:
            if selectedSheetPtr.cell(0,colIndx).value == selectedSheetPtr.cell(0,colIndx+1).value:
                multipleDict = {}
                tempMultiDict = {}
                contentExist = False

                if multiStep is False:
                    testcaseNumber =  str(selectedSheetPtr.cell(TCObjectNumberIndex,colIndx).value).strip()

                for rowIndx in range(rowStartTime,selectedSheetPtr.nrows):
                    if (((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Inputs') or ((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Outputs')):
                        if len(str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()) > 0 :
                            inOutVal = (selectedSheetPtr.cell(rowIndx,1).value).strip()
                            try:
                                re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()
                            except:
                                multipleDict[inOutVal] = str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()
                                contentExist = True
                if contentExist is True:
                    multiStep = True
                    tempMultiDict[str(selectedSheetPtr.cell(rowStartTime,colIndx).value).strip()] = multipleDict
                    tempMultiList.append(tempMultiDict)
            else:
                if multiStep is True:

                    multipleDict = {}
                    tempMultiDict = {}
                    contentExist = False
                    for rowIndx in range(rowStartTime,selectedSheetPtr.nrows):
                        if (((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Inputs') or ((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Outputs')):
                            if len(str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()) > 0 :
                                inOutVal = (selectedSheetPtr.cell(rowIndx,1).value).strip()
                                try:
                                   re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()
                                except:
                                    multipleDict[inOutVal] = str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()
                                    contentExist = True
                    if contentExist is True:
                        tempMultiDict[str(selectedSheetPtr.cell(rowStartTime,colIndx).value).strip()] = multipleDict
                        tempMultiList.append(tempMultiDict)				

                    multiStep = False
                    multiDictVal[testcaseNumber] = tempMultiList
                    tempMultiList = []
                else: 
                    stepCounter = 1
                    singleDict = {}
                    contentExist = False
                    for rowIndx in range(rowStartTime,selectedSheetPtr.nrows):
                        if (((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Inputs') or ((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Outputs')):
                            if len(str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()) > 0 :
                                inOutVal = (selectedSheetPtr.cell(rowIndx,1).value).strip()
                                try:
                                    re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()
                                except:
                                    singleDict[inOutVal] = str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()
                                    contentExist = True
                    if contentExist is True:
                        singleDictVal[str(selectedSheetPtr.cell(TCObjectNumberIndex,colIndx).value).strip()] = singleDict
        else:
            if selectedSheetPtr.cell(0,colIndx).value == selectedSheetPtr.cell(0,colIndx-1).value:
                multipleDict = {}
                tempMultiDict = {}
                contentExist = False

                if multiStep is False:
                    testcaseNumber =  str(selectedSheetPtr.cell(TCObjectNumberIndex,colIndx).value).strip()

                for rowIndx in range(rowStartTime,selectedSheetPtr.nrows):
                    if (((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Inputs') or ((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Outputs')):
                        if len(str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()) > 0 :
                            inOutVal = (selectedSheetPtr.cell(rowIndx,1).value).strip()
                            try:
                                re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()
                            except:
                                multipleDict[inOutVal] = str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()
                                contentExist = True
                if contentExist is True:
                    multiStep = True
                    tempMultiDict[str(selectedSheetPtr.cell(rowStartTime,colIndx).value).strip()] = multipleDict
                    tempMultiList.append(tempMultiDict)

                    multiDictVal[testcaseNumber] = tempMultiList
                    tempMultiList = []					
            else:
                stepCounter = 1
                singleDict = {}
                contentExist = False
                for rowIndx in range(rowStartTime,selectedSheetPtr.nrows):
                    if (((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Inputs') or ((selectedSheetPtr.cell(rowIndx,0).value).strip() == 'Outputs')):
                        if len(str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()) > 0 :
                            inOutVal = (selectedSheetPtr.cell(rowIndx,1).value).strip()
                            try:
                                re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()
                            except:
                                singleDict[inOutVal] = str(selectedSheetPtr.cell(rowIndx,colIndx).value).strip()
                                contentExist = True
                if contentExist is True:
                    singleDictVal[str(selectedSheetPtr.cell(TCObjectNumberIndex,colIndx).value).strip()] = singleDict	

    return singleDictVal,multiDictVal

if __name__ == '__main__':
#def startFun(tcPath,TCSheet,TCSheetIndex,tpPath,TPSheet,TPSheetIndex):

 #   pwd=(re.search('(.*)/.*\..*$',tcPath)).groups()[0]
 #   os.chdir(pwd)

 #   testcaseTemplateSheetNumber = TCSheetIndex
 #   testProcedureTemplateSheetNumber = TPSheetIndex

#    selectedTCSheet = TCSheet
#    selectedTPSheet = TPSheet
	
    selectedTCSheet = 'CBB_TC_08092015_Template.xlsx'
    selectedTPSheet = 'CBB_08092015_Template.xlsx'	
	
    testcaseTemplateSheetNumber = 0
    testProcedureTemplateSheetNumber = 0	


    #testcaseTemplateSheetNumber = TCSheetIndex
    #testProcedureTemplateSheetNumber = TPSheetIndex		
    print('Comparision in progress....')
	
    #Read Test case values  
    xlsxPtr = open_workbook(selectedTCSheet)
    selectedSheetPtr = xlsxPtr.sheet_by_index(testcaseTemplateSheetNumber)
    singleDictCompleteTC, multiDictValCompleteTC = readTestValues(selectedSheetPtr,True)

	
    # From test case sheet read only identifiers, else report it log file
    fPtr = open('TC_TP_InOutValues_Issues.txt','w')
    initialDelay = True
    counter_val = 1
    for rowIndx2 in range(11,selectedSheetPtr.nrows):
        if (((selectedSheetPtr.cell(rowIndx2,0).value).strip() == 'Inputs') or ((selectedSheetPtr.cell(rowIndx2,0).value).strip() == 'Outputs')):        
            inOutVal = (selectedSheetPtr.cell(rowIndx2,1).value).strip()
            try:
                re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()

                #Write This content only once into the file
                if initialDelay is True:
                    initialDelay = False
                    fPtr.write('==================== Issues in Test Case Document: '+str(selectedTCSheet)+' ======================== \n\n')

                fPtr.write(''+str(counter_val)+'. Test case variable: "'+str(inOutVal)+'" cannot be compared with test proceudre (it should be identifier)\n')	
                counter_val = counter_val+1
            except:pass
	
    # Read Test Procedure values
    TPFilePtr = open_workbook(selectedTPSheet)
    TPSheetPtr = TPFilePtr.sheet_by_index(testProcedureTemplateSheetNumber)
    singleDictCompleteTP, multiDictValCompleteTP = readTestValues(TPSheetPtr,False)


    initialDelay = True
    counter_val = 1
    for rowIndx2 in range(11,TPSheetPtr.nrows):
        if (((TPSheetPtr.cell(rowIndx2,0).value).strip() == 'Inputs') or ((TPSheetPtr.cell(rowIndx2,0).value).strip() == 'Outputs')):        
            inOutVal = (TPSheetPtr.cell(rowIndx2,1).value).strip()
            try:
                re.search(r'.*[\s]+.*',inOutVal,re.I|re.M).groups()

                #Write This content only once into the file
                if initialDelay is True:
                    initialDelay = False
                    fPtr.write('\n\n==================== Issues in Test Procedure Document: '+str(selectedTPSheet)+' ======================== \n\n')

                fPtr.write(''+str(counter_val)+'. Test case variable: "'+str(inOutVal)+'" cannot be compared with test proceudre (it should be identifier)\n')	
                counter_val = counter_val+1
            except:pass

    #Write TC and TP value mismatches into failure log
    fPtr.write('\n\n==================== TC and TP value mismatches ======================== \n\n')
    counterValMismatches = 1

    #Compare singleDictCompleteTC with singleDictCompleteTP and multiDictValCompleteTP
    if len(singleDictCompleteTC) > 0:
        if len(singleDictCompleteTP) > 0:
            for TCDictVal in singleDictCompleteTC:
                for TPDictVal in singleDictCompleteTP:
                    TPKeyValAfterSplit = TPDictVal.split('\n')
                    TCTraceInTPKeyValues = []
					
                    for TPKeyVal in TPKeyValAfterSplit:
                        TCTraceInTPKeyValues.append(TPKeyVal.strip())

                    #Check if TC trace exist in current test procedure
                    if TCDictVal.strip() in TCTraceInTPKeyValues:
                        for TCDictVal2 in singleDictCompleteTC[TCDictVal]:
                            for TPDictVal2 in singleDictCompleteTP[TPDictVal]:
                                if TCDictVal2.strip() ==  TPDictVal2.strip():
								
                                    try:
                                        TCVal = str(singleDictCompleteTC[TCDictVal][TCDictVal2]).strip()
                                        TCVal = re.search('(.*)\.0$',TCVal,re.I|re.M).groups()[0]
                                    except:
                                        TCVal = str(singleDictCompleteTC[TCDictVal][TCDictVal2]).strip()
                                        try:
                                            TCVal_Temp1 = TCVal.split('.')[0]										
                                            TCVal_Temp2 = TCVal.split('.')[1]
                                            if len(TCVal_Temp2)>6:
                                                res = str(TCVal_Temp1)+'.'+str(TCVal_Temp2[1][:6])
                                                TCVal = res
                                        except:pass
										
                                    try:
                                        TPVal = str(singleDictCompleteTP[TPDictVal][TPDictVal2]).strip()
                                        TPVal = re.search('(.*)\.0$',TPVal,re.I|re.M).groups()[0]
                                    except:
                                        TPVal = str(singleDictCompleteTP[TPDictVal][TPDictVal2]).strip()
                                        try:
                                            TPVal_Temp1 = TPVal.split('.')[0]										
                                            TPVal_Temp2 = TPVal.split('.')[1]
                                            if len(TPVal_Temp2)>6:
                                                res = str(TPVal_Temp1)+'.'+str(TPVal_Temp2[1][:6])
                                                TPVal = res
                                        except:pass								
								
                                    if TCVal != TPVal:
                                        fPtr.write('\n\n'+str(counterValMismatches)+'. Test case Tag: "'+str(TCDictVal)+'" values mismatch in TC and TP. \n\t\tTC variable: "'+str(TCDictVal2.strip())+'" value: '+str(TCVal).strip()+'\n\t\tTP variable: "'+str(TPDictVal2.strip())+'" value: '+str(TPVal).strip()+'')
                                        counterValMismatches = counterValMismatches+1 

        if len(multiDictValCompleteTP) > 0:
            listOfFailures = [] 
            for TCDictVal in singleDictCompleteTC:
                for TPDictVal in multiDictValCompleteTP:
                    TPKeyValAfterSplit = TPDictVal.split('\n')
                    TCTraceInTPKeyValues = []

                    for TPKeyVal in TPKeyValAfterSplit:
                        TCTraceInTPKeyValues.append(TPKeyVal.strip())
        
                    #Check if TC trace exist in current test procedure
                    if TCDictVal.strip() in TCTraceInTPKeyValues:
                        for TCDictVal2 in singleDictCompleteTC[TCDictVal]:
                            TCAndTPMatchCount = 0
                            informaionFailure = ''
                            for TPDictVal2 in multiDictValCompleteTP[TPDictVal]:
                                for TPDictVal3 in TPDictVal2:
                                    for TPDictVal4 in TPDictVal2[TPDictVal3]:
                                        if TCDictVal2.strip() ==  TPDictVal4.strip():

                                            try:
                                                TCVal = str(singleDictCompleteTC[TCDictVal][TCDictVal2]).strip()
                                                TCVal = re.search('(.*)\.0$',TCVal,re.I|re.M).groups()[0]
                                            except:
                                                TCVal = str(singleDictCompleteTC[TCDictVal][TCDictVal2]).strip()
                                                try:
                                                    TCVal_Temp1 = TCVal.split('.')[0]										
                                                    TCVal_Temp2 = TCVal.split('.')[1]
                                                    if len(TCVal_Temp2)>6:
                                                        res = str(TCVal_Temp1)+'.'+str(TCVal_Temp2[1][:6])
                                                        TCVal = res
                                                except:pass
										
                                            try:
                                                TPVal = str(TPDictVal2[TPDictVal3][TPDictVal4]).strip()
                                                TPVal = re.search('(.*)\.0$',TPVal,re.I|re.M).groups()[0]
                                            except:
                                                TPVal = str(TPDictVal2[TPDictVal3][TPDictVal4]).strip()

                                                try:
                                                    TPVal_Temp1 = TPVal.split('.')[0]										
                                                    TPVal_Temp2 = TPVal.split('.')[1]
                                                    if len(TPVal_Temp2)>6:
                                                        res = str(TPVal_Temp1)+'.'+str(TPVal_Temp2[1][:6])
                                                        TPVal = res
                                                except:pass												
												
                                            if  TCVal != TPVal:
                                                informaionFailure = 'Test case Tag: "'+str(TCDictVal)+'" values mismatch in TC and TP. \n\t\tTC variable: "'+str(TCDictVal2.strip())+'" value: '+str(TCVal).strip()+'\n\t\tTP variable: "'+str(TPDictVal4.strip())+'" value: TC value Not matched with any vlaue in all time cycles in traced step'
                                            else:
                                                TCAndTPMatchCount = TCAndTPMatchCount+1
                            if (TCAndTPMatchCount == 0) and (len(informaionFailure)>0): 
                                listOfFailures.append(informaionFailure)
            if len(listOfFailures):
                listOfFailures = list(OrderedDict.fromkeys(listOfFailures))
                for indx_val2 in listOfFailures:
                    fPtr.write('\n\n'+str(counterValMismatches)+'. '+indx_val2)
                    counterValMismatches = counterValMismatches+1

    #Compare multiDictValCompleteTC with multiDictValCompleteTP
    if (len(multiDictValCompleteTC) > 0):
        prevCycleTC = ''
        listOfErrors = []
        for indx_val_info in multiDictValCompleteTC:  #{'TXB-HLC-TC_5223': [{'t': {'swpd_enum_Skf1Valid': 'Valid'}}}
            colNum = 2 
            lenOfTC = len(multiDictValCompleteTC[indx_val_info])
            while(colNum <= TPSheetPtr.ncols-1):
                testcaseTrace = []
                if len(str(TPSheetPtr.cell(5,colNum).value))>0: 
                    testCaseTag = str(TPSheetPtr.cell(5,colNum).value).split('\n')
                else:
                    testCaseTag = []				
                for indxValue3 in testCaseTag:
                    testcaseTrace.append(indxValue3)
                if indx_val_info in testcaseTrace:
                    for indxNextVal in multiDictValCompleteTC[indx_val_info]:#{'t': {'swpd_enum_Skf1Valid': 'Valid'}}
                        for indxNextVal2 in indxNextVal: #'t': {'swpd_enum_Skf1Valid': 'Valid'}
                            for indxNextVal3 in indxNextVal[indxNextVal2]: #{{'swpd_enum_Skf1Valid': 'Valid'},{,},...}
                                for rowIndxVal in range(9,TPSheetPtr.nrows): # sheet index
                                    if str(TPSheetPtr.cell(rowIndxVal,1).value).strip() == indxNextVal3.strip():
                                        if colNum >= TPSheetPtr.ncols-1: 
                                            pass
                                        else:   
										
                                            try:
                                                TCVal = (indxNextVal[indxNextVal2][indxNextVal3]).lower()
                                                TCVal = re.search('(.*)\.0$',TCVal,re.I|re.M).groups()[0]
                                            except:
                                                TCVal = (indxNextVal[indxNextVal2][indxNextVal3]).lower()

                                                try:
                                                    TCVal_Temp1 = TCVal.split('.')[0]										
                                                    TCVal_Temp2 = TCVal.split('.')[1]
                                                    if len(TCVal_Temp2)>6:
                                                        res = str(TCVal_Temp1)+'.'+str(TCVal_Temp2[1][:6])
                                                        TCVal = res
                                                except:pass	

                                            try:
                                                TPVal = (str(TPSheetPtr.cell(rowIndxVal,colNum).value).strip()).lower()
                                                TPVal = re.search('(.*)\.0$',TPVal,re.I|re.M).groups()[0]
                                            except:
                                                TPVal = (str(TPSheetPtr.cell(rowIndxVal,colNum).value).strip()).lower()

                                                try:
                                                    TPVal_Temp1 = TPVal.split('.')[0]										
                                                    TPVal_Temp2 = TPVal.split('.')[1]
                                                    if len(TPVal_Temp2)>6:
                                                        res = str(TPVal_Temp1)+'.'+str(TPVal_Temp2[1][:6])
                                                        TPVal = res
                                                except:pass	
										
                                            if  TCVal != TPVal:										
                                                listOfErrors.append('Test cae Tag: "'+indx_val_info+'" values mismatch in TC and TP at cycle: '+str(indxNextVal2)+'\n\t\tTC variable: "'+str(indxNextVal3).strip()+'" value: '+str(TCVal)+'\n\t\tTP variable: '+str(TPSheetPtr.cell(rowIndxVal,1).value).strip()+' value: '+str(TPVal).strip()+'')
                        colNum = colNum+1	
                else:
                    colNum = colNum+1											                    

        listOfErrors = list(OrderedDict.fromkeys(listOfErrors))
        for indx3 in listOfErrors:
            fPtr.write('\n\n'+str(counterValMismatches)+'. '+str(indx3))
            counterValMismatches = counterValMismatches+1			
    fPtr.close()