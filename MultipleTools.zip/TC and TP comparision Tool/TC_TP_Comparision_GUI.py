from tkinter import *
import tkinter as tk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox
from tkinter import ttk
import TC_TP_Comparision
class GUI_COntroller:
    '''
	   This class initialize the required controls for TkInter GUI
	'''
    def __init__(self,TkObject1):
 
        global TkObject  
        TkObject = TkObject1
	    #Load company image
        Imageloc=tk.PhotoImage(file='logo_gif.gif')		
        label3=Label(image=Imageloc,)
        label3.image = Imageloc		
        label3.place(x=200,y=30)
		
        #label
        label_MyName = Label(TkObject,bd=7, text="For any clarification on this tool contact", bg='gray', fg="black",font=200)	
        label_MyName.place(x=20,y=450)

        #label
        label_MyName = Label(TkObject,bd=7, text="masthanvali.s@silver-atena.com", bg='gray', fg="blue",font=200)
        label_MyName.place(x=300,y=450)

        global TkObject_ref
        TkObject_ref =  TkObject       

        #Run Window
        global button2		
        button5 = Button(TkObject_ref,text='Compare TC and TP',font=10,bd=5,command=TestScript.RunTest)
        button5.place(x=200,y=130)
		
        #Exit Window
        global button2		
        button2=Button(TkObject,activebackground='green',borderwidth=5, text='Close Window', command=GUI_COntroller.exitWindow)
        button2.place(x=450,y=130)	
		
        #label
        global label1		
        label1 = Label(TkObject,bd=7, text="Select TC:", bg="yellow", fg="black",font=200)	
        label1.place(x=50,y=200)
        
        #select file
        global 	button1	
        button1=Button(TkObject,activebackground='green',borderwidth=5, text='Select TC Template!!',width=25, command=GUI_COntroller.openfile_TC)
        button1.place(x=330,y=200)		

        #label
        global label122		
        label122 = Label(TkObject,bd=7, text="TC Tempalte sheet number:", bg="yellow", fg="black",font=200)	
        label122.place(x=50,y=250)	

        global EntryObj22
        EntryObj22 = Entry(TkObject_ref,font=10,bd=5)
        EntryObj22.place(x=330,y=250)
		
        #label
        global label2	
        label2 = Label(TkObject,bd=7, text="Select TP:", bg="yellow", fg="black",font=200)	
        label2.place(x=50,y=340)
        
        #select file
        global 	button122
        button122=Button(TkObject,activebackground='green',borderwidth=5, text='Select TP Template!!',width=25, command=GUI_COntroller.openfile_TP)
        button122.place(x=330,y=340)

        #label
        global label1222		
        label1222 = Label(TkObject,bd=7, text="TP Tempalte sheet number:", bg="yellow", fg="black",font=200)	
        label1222.place(x=50,y=400)	

        global EntryObj222
        EntryObj222 = Entry(TkObject_ref,font=10,bd=5)
        EntryObj222.place(x=330,y=400)		

		
    def exitWindow():
        	 TkObject_ref.destroy()

    def openfile_TC():
        global filepath_TC,filepath_temp_TC
        filepath_TC = askopenfilename()
        filepath_temp_TC=filepath_TC.split('/')
        filepath_temp_TC=filepath_temp_TC[len(filepath_temp_TC)-1]
		
        if not (filepath_temp_TC.endswith('xls') or filepath_temp_TC.endswith('xlsx') or filepath_temp_TC.endswith('xlsm')):
            messagebox.showerror('Error','Select only xls/xlsx file!!')
            TkObject_ref.destroy()	

        label2.destroy()
        button1.destroy()
        
        #label
        global label11		
        label11 = Label(TkObject,bd=7, text="Selected TC:", bg="yellow", fg="black",font=200)	
        label11.place(x=50,y=200)


        #label
        global label111		
        label111 = Label(TkObject,bd=7, text=str(filepath_temp_TC), bg="yellow", fg="black",font=200)	
        label111.place(x=330,y=200)
        
		
    def openfile_TP():
        global filepath_TP,filepath_temp_TP	
        filepath_TP = askopenfilename()
        filepath_temp_TP=filepath_TP.split('/')
        filepath_temp_TP=filepath_temp_TP[len(filepath_temp_TP)-1]
		
        if not (filepath_temp_TP.endswith('xls') or filepath_temp_TP.endswith('xlsx') or filepath_temp_TP.endswith('xlsm')):
            messagebox.showerror('Error','Select only xls/xlsx file!!')
            TkObject_ref.destroy()

        label1.destroy()
        button122.destroy()
			
        #label
        global label11		
        label11 = Label(TkObject,bd=7, text="Selected TP:", bg="yellow", fg="black",font=200)	
        label11.place(x=50,y=340)


        #label
        global label111		
        label111 = Label(TkObject,bd=7, text=str(filepath_temp_TP), bg="yellow", fg="black",font=200)	
        label111.place(x=330,y=340)

    def openfile():
        global filepath
        filepath = askdirectory()

        label6= Label(TkObject_ref,bg='orange',text='Selected Path: ',font=40)
        label6.place(x=30,y=250)		
		
        EntryObj2 = Entry(TkObject_ref,font=10)
        EntryObj2.place(x=170,y=250,width=350)
        EntryObj2.insert(0,filepath)
        EntryObj2.configure(state='readonly')	
		
class TestScript:
    def RunTest():

        try:
            tcSheetNumber = int(EntryObj22.get())
            tpSheetNumber = int(EntryObj222.get())
        except:
            messagebox.showerror('Error','Enter Sheet Number')
            TkObject_ref.destroy()   
            sys.exit()			
		
        tcPath = filepath_TC
        tcName = filepath_temp_TC

        tpPath = filepath_TP
        tpName = filepath_temp_TP
         		
        print('tcPath: '+str(tcPath))
        print('tpPath: '+str(tpPath))		
        TC_TP_Comparision.startFun(tcPath,tcName,tcSheetNumber,tpPath,tpName,tpSheetNumber,TkObject_ref)
		

if __name__ == '__main__':
	
    root = tk.Tk()
    
    #Change the background window color
    root.configure(background='gray')     
    
    #Set window parameters
    root.geometry('700x500')
    root.title('Welcome to TC and TP comparision tool')
    
    #Removes the maximizing option
    root.resizable(0,0)
    
    ObjController = GUI_COntroller(root)
    
    #keep the main window is running
    root.mainloop()
    