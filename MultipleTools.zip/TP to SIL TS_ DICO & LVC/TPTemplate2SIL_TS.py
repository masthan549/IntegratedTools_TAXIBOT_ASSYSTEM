import re,sys,os
from xlrd import open_workbook
from tkinter import *
from tkinter import messagebox

def GenerateTS(filepath,filepath_temp,TkObject_ref,sheetIndx,systemExeTime,SILScriptStartTime,globalReqNum):
    '''
	   This function converts the TS into SIL TS
	'''

############# Enter these details ################ 

    try:
        XlsName = filepath_temp
        sysExecTime = int(systemExeTime)
        sheetIndx = int(sheetIndx)-1
        startTime = int(SILScriptStartTime)
        actualTimeDiff = 100/20 # 100 is the max time and 20 is min processing time 
    except:
        messagebox.showerror('Error','May be you have entered incorrect values in required fields')
        TkObject_ref.destroy()		
#############################

    pwd=(re.search('(.*)/.*\..*$',filepath)).groups()[0]
    os.chdir(pwd)

    try: 
        XlsName_Modified = XlsName.split('.xl')
	    
        #Open xls sheet 
	    
        fptr = open_workbook(XlsName)
        HLTP_Template = fptr.sheet_by_index(sheetIndx)
        rows = HLTP_Template.nrows
        cols = HLTP_Template.ncols
    except:
        messagebox.showerror('Error','Error occured while opening selected file')
        TkObject_ref.destroy()		
		
    	
    #open text file
    os.chdir(os.getcwd())
    SILTS = open(XlsName_Modified[0]+'_HL_TEST.txt','w')
	
    print('\nExecution in Progress...')  

    InputStartAt = 0  
    OutputStartAt = 0	
    InputProcessingRate = []
    inputStarted = False
    OutputStarted = False		
	
    #Read starting index of Inputs and outputs. Also read all inputs processing rate
    for indx in range(9,rows):
        if HLTP_Template.cell(indx,0).value == 'Inputs':
            if inputStarted is False:
                InputStartAt = indx
                inputStarted = True
            if len(str(HLTP_Template.cell(indx,3).value).strip())>0:
                try:
                    InputProcessingRate.append(int(HLTP_Template.cell(indx,3).value))
                except: 
                    print("processing rate should be of type integer at row number: "+str(indx+1)+"")
                    sys.exit()				
            else:
                print('Input processing rate must be specified for every input (missing at row: '+str(indx+1)+')')
                sys.exit()  

        if HLTP_Template.cell(indx,0).value == 'Outputs':
            if OutputStarted is False:
                OutputStartAt = indx
                OutputStarted = True
				
    initDelay = True
    seqCounter = 0
    #read through all columns of selected sheet  
    for indx in range(4,cols):

        inputInfo = []
        outputInfo = []
        # read complete data of every row
        for rowIndx in range(9,rows):
            inOutVal = str(HLTP_Template.cell(rowIndx,indx).value)
            val = HLTP_Template.cell(rowIndx,indx).value
            try:
                re.search('.*\\.0$',inOutVal).groups()
                val = int(val)
            except:pass			
		
            if rowIndx >= InputStartAt and rowIndx < OutputStartAt:
                inputInfo.append(val)
            elif rowIndx >= OutputStartAt:
                outputInfo.append(val)    

        #push the xls info into text file
        currCycleTime = HLTP_Template.cell(8,indx).value
        if indx+1 >= cols:
            NextCycleTime = currCycleTime+sysExecTime
        else: 
            NextCycleTime = HLTP_Template.cell(8,indx+1).value		

        numberOfCycles = int((NextCycleTime - currCycleTime)/sysExecTime)

        if numberOfCycles<=0:
            print("Time diff between two cycles should be greater than or equal to system execution time: "+str(sysExecTime)+" at column number: "+str(indx)+"")
            sys.exit()

        if len(inputInfo) != len(InputProcessingRate):
            print("Number of inputs and processing time which is specifed does not match!!")
            sys.exit() 

        counter = 0
        for listIndx in range(0,numberOfCycles):
            counter = counter+1
            cycleInfo = ''
            startTime = startTime+sysExecTime
            seqCounter = seqCounter+1
            cycleInfo = ' 1, '+str(startTime)+',D, '+str(globalReqNum)+', '+str(seqCounter)+', '
            print("Timer: "+str(startTime)+" and repeat seq: "+str(counter)+"")
            for inputVal in range(0,len(inputInfo)):
                if (indx == 4) and (initDelay is True):
                    cycleInfo = cycleInfo+str(inputInfo[inputVal])+', '                    
                elif InputProcessingRate[inputVal] == sysExecTime:
                    cycleInfo = cycleInfo+str(inputInfo[inputVal])+', '
                elif (((startTime-20)%100) == 0):
                    cycleInfo = cycleInfo+''+str(inputInfo[inputVal])+', '                       
                elif InputProcessingRate[inputVal] != sysExecTime:
                    cycleInfo = cycleInfo+'X, '

            initDelay = False 				
            for outputVal in outputInfo:
                cycleInfo = cycleInfo+''+str(outputVal)+', '
            SILTS.write(cycleInfo+'\n')
	
 
    SILTS.close()
    messagebox.showinfo('Results','Results are generated in '+str(XlsName_Modified[0]+'_HL_TEST.txt'))
    TkObject_ref.destroy()			
#fp = "C:\Masthan\My Tools\TAXIBOT\TP to SIL TS_ DICO & LVC"
#xlName = 'DICO_SCRIPT_HL_NOM_2.xls'		
#sheetIndx = 1		
#systemExeTime = 20
#SILScriptStartTime = 400
#		
#GenerateTS(fp,xlName,sheetIndx,systemExeTime)